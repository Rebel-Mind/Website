1. wireframing
2. Create a clear product design
3. Re-pitch idea
4. Make sure that it is an origninal idea